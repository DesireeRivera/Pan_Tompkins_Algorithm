function[pospicos,elecg,elecgO,ecg_d,ecg_e,ecg_C,ecg_i,ecg_i2,locs_Qwave,S_A, S_t,Q_A,Q_t]=thresholding(ssc,t6,Fs)
%FILTRADO DE ARTEFACTOS EN LA SEÑAL

% Filtramos la señal para eliminar lo que no es señal de interés. 
%El componente QRS se encuentra entre 5Hz y 15 Hz en el dominio de la frecuencia con lo cual 
%el objetivo es eliminar las componentes espectrales fuera de ese rango 
%No obstante el paso alto si lo vamos a hacer con una fc = 5 Hz pero el
%filtro paso bajo lo haremos con una fc = 25 Hz ya que nos salieron mejores
%resultados para filtrar.

%PASO BAJO
%Usaremos un filtro Butterworth  de orden 4 y fc =25 Hz
%Filtro para eliminar la posible interferencia de la red y las altas 
%frecuencias.
n=4;
fc=25;
wc= fc/(Fs/2);
[b,a] = butter(n,wc,'low');
freqz(b,a);
elecg = filtfilt(b,a,ssc);

%PASO ALTO
%Usaremos un filtro Butterworth  de orden 6 y fc = 5 Hz
%Filtro para eliminar la componente de continua y para eliminar las 
%bajas frecuencias
n=6;
fc=5;
wc= fc/(Fs/2);
[b,a] = butter(n,wc,'high');
freqz(b,a);
elecgO = filtfilt(b,a,elecg);
%Normalizamos la señal
elecgO = elecgO/ max( abs(elecgO));

%DERIVACION
% Derivar la señal nos permitirá amplificar los picos (ver donde se producen las mayores subidas 
%y bajadas, y que la derivada lo que da son los cambios de "pendiente”) , y de esa manera se 
%hace que el complejo QRS sea más evidente. 
%Codigo recopilado de la referencia 2 de la explicación de la practica
b= [1 2 0 -2 -1]*Fs/8;
a= [1];
ecg_d= filtfilt(b,a,elecgO);
%Normalizamos
ecg_d = ecg_d/max(ecg_d);

%ELEVAR A 2
%A continuación elevar al cuadrado toda la señal para convertir todos los valores a positivos y 
%aumentar los picos también y así hacer más visible el QRS. Pudiendo ver
%tres picos positivos que se corresponden a las ondas QRS y otros dos picos
%más pequeños que corresponderan a las ondas P y T
 ecg_e =ecg_d.^2;
 
 %INTEGRACION
 %Hacer una ventana integradora nos permitirá unir posibles duplicidades de picos y que se 
 %unifiquen en una única "montaña  sobre la que ya podremos poner un umbral para la 
 %detección.
 %Codigo recopilado de la referencia 2 de la explicación de la practica
 vit= 0.150*Fs;
 vit=round(vit);
 b=[1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1];
 a=vit;
 ecg_i=filtfilt(b,a,ecg_e);
 %Normalizamos
 ecg_i= ecg_i/max(abs(ecg_i));

%UMBRAL
%Hay que hacer un analisis del entorno para encontrar el latido que en este
%caso correspondera con el pico de la onda R. Para ello establecemos un
%umbral de 0.2 en lo que todo lo mayor a 0.2 es igual a 1 y el resto será 0
 u=.2;
  ene=length(ecg_i);
 ecg_C=ecg_i;
 for i=1:ene
     if ecg_C(i)<u
         ecg_C(i)=0;
     end
     if ecg_C(i)>u
         ecg_C(i)=1;
     end
 end

 %DETECTAR DONDE ESTA EL EL LATIDO
 %Para detectar el latido hemos usado dos metodos
 %El primero es usando el findpeaks en el que usaremos el umbral calculado
 %anteriormente
 [~,locs_Qwave] = findpeaks(ssc,'MinPeakHeight',0.2,...
                                    'MinPeakDistance',100);
%OTRA MANERA DE DETECTAR LATIDOS
%La segunda manera será recorriendo la señal de la ventana integradora en
%que cuando tenga un latido nos meta las posiciones de la muestra en un
%vector
pospicos=[];
i=1;
 while i<length(ecg_i)
     if ecg_i(i)>u
         posini=i;
         for j=i+1:length(ecg_i)
             if ecg_i(j)<u
                 posfinal=j;
                 i=j;
                 break
             end
         end
         %Hacemos la media de la posición inicial y final para sacar el
         %pico de la onda R que estaría en el centro
         pospicos=[pospicos floor((posini+posfinal)/2)];
     end
     i=i+1;
 end

%EMPIEZE Y ACABADO QRS
%Al hacer todos los proceso de derivación, elevación al cuadrado y la ventana integradora se deberia de haber desplazado la señal en el tiempo hacia la
%derecha. Este hecho no ha ocurrido al usar la función filtfilt. Como en
%las referencias de la practica y mejor explicado en la presentación se verá necesario este desplazamiento para coger el principio de la señal de la ventana
%integradora y el punto más alto. Para ello s¡hacemos otra vez los mismo
%procesos pero filtrando con Filter
%DERIVACION
b= [1 2 0 -2 -1]*Fs/8;
a= [1];
ecg_d2= filter(b,a,elecgO);
ecg_d2 = ecg_d2/max(ecg_d2);
 %ELEVAR A 2
 ecg_e2 =ecg_d2.^2;
 %INTEGRACION
 vit= 0.150*Fs;
 vit=round(vit);
 b=[1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1];
 a=vit;
 ecg_i2=filter(b,a,ecg_e2);
 ecg_i2= ecg_i2/max(abs(ecg_i2));

 %Llegados aqui cogimos el codigo de https://es.mathworks.com/matlabcentral/fileexchange/66098-ecg-p-qrs-t-wave-detecting-matlab-code?s_tid=mlc_recom_leaf
 % En esa pagina web servia para detectar los picos de todas la ondas
 %Aqui lo implementaremos para nuestro caso
 %En este codigo hará la derivada (o derivada aproximada) de la señal del
 %umbral en el que nos dará una señal que indica el principio y el final de
 %la señal del umbral
 difsig=diff(ecg_C);
 %Cogemos los puntos del inicio del umbral
left=find(difsig==1);
%Cogemos los puntos del final umbral
raight=find(difsig==-1);

   % EMPIEZE QRS
for i=1:length(left)
    %Cogemos los puntos maximos de la señal de la ventana integradora
    [S_A(i) S_t(i)]=max(ecg_i2(left(i):raight(i)));
    S_t(i)=S_t(i)-1+left(i)%add offset
  %Cogemos los puntos minimos de comienzo de la señal de la ventana integradora
    [Q_A(i) Q_t(i)]=min(ecg_i2(left(i):raight(i)));
    Q_t(i)=Q_t(i)-1+left(i) %add offset
end

 
end