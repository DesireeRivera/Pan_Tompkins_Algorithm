%TITULO:PRACTICA QRS. 
%FECHA: 20/01/2023
%NOMBRE Y APELLIDOS:MERCEDES CRISTINA CORDERO MARTINEZ Y DESIRÉE RIVERA RODRÍGUEZ. 
%GRADO: INGENIERIA BIOMÉDICA.
%ASIGNATURA: TRATAMIENTO Y PROCESADO DE LA SEÑAL

%INICIO
clear all;
close all;
clc;

%En esta práctica se realizarán algunas técnicas habituales en el procesamiento de señales ECG.
%Una de esas técnicas es el método de Tompkins el cual es un algoritmo que
%nos permite detectar donde están los latidos de una persona.
% Para ello detectaremos el complejo QRS el cual representa la despolarización ventricular y además
% es el pico principal visible en una señal de ECG. 
% Esta característica lo hace especialmente adecuado para medir la frecuencia cardíaca que es la primera forma de evaluar el estado de salud del corazón.
% En la primera derivación de Einthoven de un corazón fisiológico, el complejo QRS está compuesto por una desviación hacia abajo (onda Q),
% una desviación alta hacia arriba (onda R) y una desviación final hacia abajo (onda S)

%A continuación explicaremos los pasos de este algoritmo

%CARGAMOS LA SEÑAL
%Descargamos la señal gracias a rdsamp
%Como queremos coger 1 min para ello multiplicamos 60 s a la frecuencia de
%muestreo que es 360 dandonos un total de 21600.

%Por lo tanto descargaremos de la muestra 1 a la 21600
[signal,Fs,tm]=rdsamp('mitdb/100',[],21600);
%Cogemos la primera señal
signal=signal(:,1);

%PRE-PROCESAMIENTO DE LA SEÑAL
%Antes de aplicar el algoritmo a la señal hay que prepararla.
%Ajustamos el tiempo cogiendo toda las muestras y la dividimos entre su FS
t6=(1:length(signal))/Fs;

%Ajustamos su amplitud
ecg_mv= (signal)/max(signal);%Amplitud ajustada

%La centramos en el eje 0
continua= mean(ecg_mv);
%Después le quitamos esa media a los valores de la señal original
ssc=(ecg_mv-continua)/std(ecg_mv);%Señal centrada

%Normalizamos la señal
ssc=ssc/max(ssc);

%Vemos en el dominio de la frecuencia que pasa en la señal original viendo
%esa componente continua que vamos a elimininar
%En el dominio de la frecuencia
tfshiftssc=fftshift(fft(signal));
% Creamos el eje para hacer un eje de tiempos
ejeff= linspace(-Fs/2,Fs/2,length(tfshiftssc))



%Echamos vistazo a la señal pre-procesada comparandola con la original 
%En el dominio del tiempo
figure, subplot(211), plot(t6,signal), title('Señal original'), subplot(212),plot(t6,ssc,'r'),title('Señal pre-procesada')

%En el dominio de la frecuencia
tfshiftssc=fftshift(fft(ssc));
% Creamos el eje para hacer un eje de tiempos
ejeff0= linspace(-Fs/2,Fs/2,length(tfshiftssc));
%Gráficamos utilizando el subplot
figure,subplot(211), plot(ejeff0,abs(tfshiftssc/length(ssc))),title('Transformada de Fourier de la Señal pre-procesada'),subplot(212), plot(ejeff,abs(tfshiftssc/length(signal))),title('Transformada de Fourier de la Señal original')

%FUNCION
%Se ha creada una función en la que pasamos los datos de frecuencia, tiempo
%y las muestras del ecg la cual llamaremos en todas las ECGs para
%devolvernos los picos detectados y tambien los vectores que contendrán las
%señales de las distintas etapas.
[pospicos,elecg,elecgO,ecg_d,ecg_e,ecg_C,ecg_i,ecg_i2,locs_Qwave,S_A, S_t,Q_A,Q_t]=qrs_deteccion_prueba(ssc,t6,Fs);

%La explicación de las distintas fases se hacen en la funcion
%qrs_deteccion_prueba.m 
% En este script solo veremos los resultados

%FILTRADO DE ARTEFACTOS EN LA SEÑAL
%PASO BAJO
%En el dominio del tiempo
figure, subplot(211), plot(t6,ssc), title('Señal original'), subplot(212),plot(t6,elecg,'r'),title('Señal filtrada FPB')
%En el dominio de la frecuencia
tfshiftssc1=fftshift(fft(elecg));
% Creamos el eje para hacer un eje de tiempos
ejeff1= linspace(-Fs/2,Fs/2,length(tfshiftssc1));
%Gráficamos utilizando el subplot
figure, subplot(211),plot(ejeff1,abs(tfshiftssc1/length(elecg))),title('Transformada de Fourier de la Señal FPB'),subplot(212), plot(ejeff,abs(tfshiftssc/length(ssc))),title('Transformada de Fourier de la Señal pre-procesada')

%PASO ALTO
%En el dominio del tiempo
figure, subplot(211), plot(t6,elecg), title('Señal original'), subplot(212),plot(t6,elecgO,'r'),title('Señal filtrada')
%En el dominio de la frecuencia
tfshiftssc2=fftshift(fft(elecgO));
% Creamos el eje para hacer un eje de tiempos
ejeff2= linspace(-Fs/2,Fs/2,length(tfshiftssc2));
%Gráficamos utilizando el subplot
figure, subplot(211),plot(ejeff2,abs(tfshiftssc2/length(elecgO))),title('Transformada de Fourier de la Señal FPA'),subplot(212), plot(ejeff1,abs(tfshiftssc1/length(elecg))),title('Transformada de Fourier de la Señal FPB')

%Comparación
figure,plot(t6,ssc/max(ssc)), title('Señal original'), hold on,plot(t6,elecgO,'r'),title('Señal filtrada')

%DERIVACION
%Visualizamos resultado
figure,plot(t6,ecg_d),title('Fase de derivación')

%ELEVAR A 2
%Visualizamos resultado
figure,plot(t6,ecg_e),title('Fase de elevar al cuadrado')

%INTEGRACION
%Visualizamos resultado
 figure,plot(t6,ecg_i),title('Fase de integración')

 %UMBRAL
 %Visualizamos resultado
   figure, plot(t6,ecg_C),hold on, plot(t6,ecg_i,'r'), title('Umbral')

   %DETECCION DE LATIDOS (TOMA DE DECISIÓN)
   %Visualizamos resultado
figure,plot(locs_Qwave,ssc(locs_Qwave),'rv','MarkerFaceColor','r'),hold on, plot(ssc),hold on,plot(pospicos,ssc(pospicos),'k*'), title('Detección de latidos')

%EMPIEZE Y ACABADO QRS
%En este plot podemos ver como cogemos los puntos correspondientes de
%nuestra integracción que corresponden al principio y final del QRS
figure,plot(t6,ecg_i2,t6(Q_t),Q_A,'*b'),hold on,
plot(t6,ecg_i2,t6(S_t),(S_A),'*r'),hold on, plot(t6,ecg_i2)

%En este plot representamos el principio y final de la señal
figure,plot(ssc),hold on,
plot(Q_t,ssc(Q_t),'*g'),hold on,
plot(S_t,ssc(S_t),'*r'), title ('Inicio y Final del Complejo QRS ')

%PERFORMANCE DEL ALGORITMO
%Al utilizar un algoritmo vamos a ver alguna de sus medidas de rendimiento
%Cogemos las anotaciones de physionet con la función rdann
annV=rdann('mitdb/100','atr',[],21600);
%Podemos ver que según el autor de este ECG hay 75 latidos mientras nosotros hemos detectado 74
%Vamos a ver los resultados

%Vemos las anotaciones haciendo un plot
 figure,plot(ssc),hold on,plot(annV,ssc(annV),'k*'),title ('Anotaciones ATR') ,hold on, 
 plot(pospicos,ssc(pospicos),'r*'),title ('Picos detectados'), hold on, plot(ssc)

 %Declaramos variables que serán vectores
 FP1=[];%Probabilidad que nos indica que nos hemos equivocado tratando un latido cuando no lo es
 VP1= [];%Probabilidad que nos indica que hemosdetectado un latido acertadamente
 FN1=[];%Probabilidad que nos indica que no hemos detectado un latido cuando si lo era
 detec1=[];%Vector donde guardamos las detecciones de los latidos

 %Primer bucle para detectar valores VP y FP
 for i=1:length(pospicos)
     %Encontramos las muestrasque se han detectado correctamente con un
     %margen de +/- 15 muestras de diferencia. Si los picos que hemos
     %detectado estan entre ese intervalo se dirá que es un Verdadero
     %Positivo
     if annV(find(annV >= (pospicos(i)-15) & annV <= (pospicos(i)+15)))
     detec1= [detec1 pospicos(i)];
     VP1=[VP1 pospicos(i)];
     %Sino es un falso positivo
     else
         FP1=[FP1 pospicos(i)];    
     end
 end

 %Primer bucle para detectar valores FN. En este caso hacemos el mismo solo
 %que cambiando las variable ann por pospicos del anterior bucle para que
 %encuentre si hay algun pico que se ha detectado mal o ni lo ha detectado
 %bucle
detec1=[];

 for j=1:length(annV)
      if pospicos(find(pospicos >= (annV(j)-15) & pospicos <= (annV(j)+15)))
    detec1= [detec1 annV(j)];
 
      else
         FN1=[FN1 annV(j)]; 
      end
 end

 %Calculamos la sensibilidad y el VPP
 %Para ello vamos a saber el total de las muestras que hay en VP, FP y FN
 VP1=length(VP1);
 FP1=length(FP1);
 FN1=length(FN1);
 %Después aplicamos las formulas correspondientes
 sensibilidad1= VP1/(VP1+FN1);% La sensibilidad de una prueba es la probabilidad de que la detección de un latido sea de verdad un latido en nuestro caso
 valorP1=VP1/(VP1+FP1);% La sensibilidad de una prueba es la probabilidad de que sea un latido si el resultado es positivo

 %Los resultados de esta señal ha sido una sensibilidad de 0.9867 
% Y un Valor Predictivo Positivo de 1
%Siendo muy buenos valores en el campo de la medicina ya que tiene muy
%poquito margen de error.

%No obstante hay que probar que funcione en más señales por lo que ha
%continuación se va a implementar en 9 señales más para luego discutir si
%el algoritmo es eficaz y util para utilizarlo en un diagnostico.

%Las 9 señales que vienen son cogidas tambien como la primera de la base de
%datos MIT/DB Arritmia. Seguirán los mismos procesos que la primera



%SEÑAL 2

%CARGAMOS LA SEÑAL
 [signal,Fs,tm]=rdsamp('mitdb/101',[],21600);
signal=signal(:,1);

%PRE-PROCESAMIENTO DE LA SEÑAL
t=(0:length(signal)-1)/Fs;
%Ajustar amplitud
ecg_mv= (signal)/max(signal);
%Centramos
continua= mean(ecg_mv);
%Después le quitamos esa media a los valores de la señal original
ssc1=(ecg_mv-continua)/std(ecg_mv);
%Normalizamos
ssc1=ssc1/max(ssc1);

%dominio del tiempo
figure, subplot(211), plot(t,signal), title('Señal original'), subplot(212),plot(t,ssc1,'r'),title('Señal sin continua')
%Transformada de fourier sin continua
tfshiftssc=fftshift(fft(ssc1));
% Creamos el eje para hacer un eje de tiempos
ejeff= linspace(-Fs/2,Fs/2,length(tfshiftssc))
%Dominio de Frecuencia
figure,plot(ejeff,abs(tfshiftssc/length(ssc1))),title('Transformada de Fourier Señal sin continua')

%FUNCION
[pospicos,elecg,elecgO,ecg_d,ecg_e,ecg_C,ecg_i,ecg_i2,locs_Qwave,S_A, S_t,Q_A,Q_t]=qrs_deteccion_prueba(ssc1,t,Fs)

% FILTRADO DE ARTEFACTOS
%PASO BAJO
%Dominio del tiempo
figure, subplot(211), plot(t,ssc1), title('Señal original'), subplot(212),plot(t,elecg,'r'),title('Señal filtrada FPB')
%Dominio en frecuencia
%En el dominio de la frecuencia
tfshiftssc1=fftshift(fft(elecg));
% Creamos el eje para hacer un eje de tiempos
ejeff1= linspace(-Fs/2,Fs/2,length(tfshiftssc1));
%Gráficamos utilizando el subplot
figure, subplot(211),plot(ejeff1,abs(tfshiftssc1/length(elecg))),title('Transformada de Fourier de la Señal FPB'),subplot(212), plot(ejeff,abs(tfshiftssc/length(ssc1))),title('Transformada de Fourier de la Señal pre-procesada')

%PASO ALTO
%Dominio tiempo
figure, subplot(211), plot(t,elecg), title('Señal original'), subplot(212),plot(t,elecgO,'r'),title('Señal filtrada')
%Dominio frecuencia
%En el dominio de la frecuencia
tfshiftssc2=fftshift(fft(elecgO));
% Creamos el eje para hacer un eje de tiempos
ejeff2= linspace(-Fs/2,Fs/2,length(tfshiftssc2));
%Gráficamos utilizando el subplot
figure, subplot(211),plot(ejeff2,abs(tfshiftssc2/length(elecgO))),title('Transformada de Fourier de la Señal FPA'),subplot(212), plot(ejeff1,abs(tfshiftssc1/length(elecg))),title('Transformada de Fourier de la Señal FPB')

%DERIVACION
figure,plot(t,ecg_d)

%ELEVAR A 2
figure,plot(t,ecg_e)

%INTEGRACION
 plot(t,ecg_i)

 %UMBRAL
   figure, plot(t,ecg_C),hold on, plot(t,ecg_i,'r')
   
   %DETECCION DE LATIDOS
figure,plot(locs_Qwave,ssc1(locs_Qwave),'rv','MarkerFaceColor','r'),hold on, plot(ssc1),hold on,plot(pospicos,ssc1(pospicos),'k*')

%EMPIEZE Y ACABADO QRS
figure,plot(t,ecg_i2,t(Q_t),Q_A,'*b'),hold on,
plot(t,ecg_i2,t(S_t),(S_A),'*r'),hold on, plot(t,ecg_i2)

figure,plot(ssc1),hold on,
plot(Q_t,ssc1(Q_t),'rs','MarkerFaceColor','g'),hold on,
plot(S_t,ssc1(S_t),'rv','MarkerFaceColor','r')

%PERFORMANCE
annV=rdann('mitdb/101','atr',[],21600);
figure, plot(ssc1),hold on,plot(annV,ssc1(annV),'k*'), hold on, 
 plot(pospicos,ssc1(pospicos),'r*')
 FP2=[];
 VP2= [];
 FN2=[];
 detec2=[];
 for i=1:length(pospicos)
     if annV(find(annV >= (pospicos(i)-15) & annV <= (pospicos(i)+15)))
     detec2= [detec2 pospicos(i)];
         VP2=[VP2 pospicos(i)];
     else 
         FP2=[FP2 pospicos(i)]; 
     end
     end

detec2=[];
 for j=1:length(annV)
      if pospicos(find(pospicos >= (annV(j)-15) & pospicos <= (annV(j)+15)))
    detec2= [detec2 annV(j)];
      else
         FN2=[FN2 annV(j)]; 
      end
 end
 VP2=length(VP2);
 FP2=length(FP2);
 FN2=length(FN2);
 sensibilidad2= VP2/(VP2+FN2);
 valorP2=VP2/(VP2+FP2);



 %SEÑAL 3
 %CARGAMOS LA SEÑAL
 [signal,Fs,tm]=rdsamp('mitdb/102',[],21600);
 signal=signal(:,1);

%PRE-PROCESAMOS LA SEÑAL
t2=(0:length(signal)-1)/Fs;
%Ajustar amplitud
ecg_mv= (signal)/max(signal);%Amplitud ajustada
continua= mean(ecg_mv);
%Después le quitamos esa media a los valores de la señal original
ssc2=(ecg_mv-continua)/std(ecg_mv);
ssc2=ssc2/max(ssc2);
%Dominio del tiempo
figure, subplot(211), plot(t2,signal), title('Señal original'), subplot(212),plot(t2,ssc2,'r'),title('Señal sin continua')
%Dominio en frecuencia
tfshiftssc=fftshift(fft(ssc2));
% Creamos el eje para hacer un eje de tiempos
ejeff= linspace(-Fs/2,Fs/2,length(tfshiftssc));
%Gráficamos utilizando el subplot
figure,plot(ejeff,abs(tfshiftssc/length(ssc2))),title('Señal sin continua')

%FUNCION
[pospicos,elecg,elecgO,ecg_d,ecg_e,ecg_C,ecg_i,ecg_i2,locs_Qwave,S_A, S_t,Q_A,Q_t]=qrs_deteccion_prueba(ssc2,t2,Fs);

%ElIMINACIÓN DE ARTEFACTOS
%PASO BAJO
%Dominio tiempo
figure, subplot(211), plot(t2,ssc2), title('Señal original'), subplot(212),plot(t2,elecg,'r'),title('Señal filtrada FPB')
%En el dominio de la frecuencia
tfshiftssc1=fftshift(fft(elecg));
% Creamos el eje para hacer un eje de tiempos
ejeff1= linspace(-Fs/2,Fs/2,length(tfshiftssc1))
%Gráficamos utilizando el subplot
figure, subplot(211),plot(ejeff1,abs(tfshiftssc1/length(elecg))),title('Transformada de Fourier de la Señal FPB'),subplot(212), plot(ejeff,abs(tfshiftssc/length(ssc2))),title('Transformada de Fourier de la Señal pre-procesada')

%PASO ALTO
%Dominio tiempo
figure, subplot(211), plot(t2,elecg), title('Señal filtrado FPB'), subplot(212),plot(t2,elecgO,'r'),title('Señal filtrada FPA')
%Dominio Frecuencia
%En el dominio de la frecuencia
tfshiftssc2=fftshift(fft(elecgO));
% Creamos el eje para hacer un eje de tiempos
ejeff2= linspace(-Fs/2,Fs/2,length(tfshiftssc2));
%Gráficamos utilizando el subplot
figure, subplot(211),plot(ejeff2,abs(tfshiftssc2/length(elecgO))),title('Transformada de Fourier de la Señal FPA'),subplot(212), plot(ejeff1,abs(tfshiftssc1/length(elecg))),title('Transformada de Fourier de la Señal FPB')

%DERIVACION
figure,plot(t2,ecg_d)

%ELEVAR A 2
figure, plot(t2,ecg_e)
%INTEGRACION
 figure,plot(t2,ecg_i)

 %UMBRAL
   figure, plot(t2,ecg_C),hold on, plot(t2,ecg_i,'r')
  

   %DETECCION DE LATIDOS (TOMA DE DECISIÓN)
figure, plot(locs_Qwave,ssc2(locs_Qwave),'rv','MarkerFaceColor','r'),hold on, plot(ssc2),hold on,plot(pospicos,ssc2(pospicos),'k*')

%EMPIEZE Y ACABADO QRS
figure;plot(t2,ecg_i2,t2(Q_t),Q_A,'*b'),hold on,
plot(t2,ecg_i2,t2(S_t),(S_A),'*r'),hold on, plot(t2,ecg_i2)

figure,plot(ssc2),hold on,
plot(Q_t,ssc2(Q_t),'rs','MarkerFaceColor','g'),hold on,
plot(S_t,ssc2(S_t),'rv','MarkerFaceColor','r')

%PERFORMANCE

ann2=rdann('mitdb/102','atr',[],21600);
 figure,plot(ann2,ssc2(ann2),'k*'), hold on, 
 plot(ssc2),hold on,plot(pospicos,ssc2(pospicos),'r*')
 FP3=[];
 VP3= [];
 FN3=[];
 detec3=[];
 for i=1:length(pospicos)
     if ann2(find(ann2 >= (pospicos(i)-15) & ann2 <= (pospicos(i)+15)))
     detec3= [detec3 pospicos(i)];
     VP3=[VP3 pospicos(i)];
     else
         FP3=[FP3 pospicos(i)]; 
         
     end
     end

 
detec3=[];
 for j=1:length(ann2)
      if pospicos(find(pospicos >= (ann2(j)-15) & pospicos <= (ann2(j)+15)))
    detec3= [detec3 ann2(j)];
      else
         FN3=[FN3 ann2(j)]; 
      end
 end
 VP3=length(VP3);
 FP3=length(FP3)
 FN3=length(FN3)
 sensibilidad3= VP3/(VP3+FN3)
 valorP3=VP3/(VP3+FP3)



  %SEÑAL 4
 %CARGAMOS LA SEÑAL
 [signal,Fs,tm]=rdsamp('mitdb/103',[],21600);
signal=signal(:,1);

%PRE-FILTRAMOS LA SEÑAL
t3=(0:length(signal)-1)/Fs;
%Ajustar amplitud
ecg_mv= (signal)/max(signal);%Amplitud ajustada
continua= mean(ecg_mv);
%Después le quitamos esa media a los valores de la señal original
ssc3=(ecg_mv-continua)/std(ecg_mv);
ssc3=ssc3/max(ssc3);

%Dominio en Tiempo
figure, subplot(211), plot(t3,signal), title('Señal original'), subplot(212),plot(t3,ssc3,'r'),title('Señal sin continua')

%Dominio en Frecuencia
tfshiftssc=fftshift(fft(ssc3));
% Creamos el eje para hacer un eje de tiempos
ejeff= linspace(-Fs/2,Fs/2,length(tfshiftssc));
%Gráficamos utilizando el subplot
figure,plot(ejeff,abs(tfshiftssc/length(ssc3))),title('Transformada Señal sin continua')

%FUNCION
[pospicos,elecg,elecgO,ecg_d,ecg_e,ecg_C,ecg_i,ecg_i2,locs_Qwave,S_A, S_t,Q_A,Q_t]=qrs_deteccion_prueba(ssc3,t3,Fs)

%PASO BAJO
%Dominio del tiempo
figure, subplot(211), plot(t3,ssc3), title('Señal original'), subplot(212),plot(t3,elecg,'r'),title('Señal filtrada')
%Dominio en frecuencia
%En el dominio de la frecuencia
tfshiftssc1=fftshift(fft(elecg));
% Creamos el eje para hacer un eje de tiempos
ejeff1= linspace(-Fs/2,Fs/2,length(tfshiftssc1))
%Gráficamos utilizando el subplot
figure, subplot(211),plot(ejeff1,abs(tfshiftssc1/length(elecg))),title('Transformada de Fourier de la Señal FPB'),subplot(212), plot(ejeff,abs(tfshiftssc/length(ssc3))),title('Transformada de Fourier de la Señal pre-procesada')

%PASO ALTO
figure, subplot(211), plot(t3,elecg), title('Señal original'), subplot(212),plot(t3,elecgO,'r'),title('Señal filtrada')
%En el dominio de la frecuencia
tfshiftssc2=fftshift(fft(elecgO));
% Creamos el eje para hacer un eje de tiempos
ejeff2= linspace(-Fs/2,Fs/2,length(tfshiftssc2));
%Gráficamos utilizando el subplot
figure, subplot(211),plot(ejeff2,abs(tfshiftssc2/length(elecgO))),title('Transformada de Fourier de la Señal FPA'),subplot(212), plot(ejeff1,abs(tfshiftssc1/length(elecg))),title('Transformada de Fourier FPB')

%DERIVACION
figure,plot(t3,ecg_d)

%ELEVAR A 2
figure,plot(t3,ecg_e)

%INTEGRACION
 plot(t3,ecg_i)

 %UMBRAL
   figure, plot(t3,ecg_C),hold on, plot(t3,ecg_i,'r')
 
   %DETECCION DE LATIDOS
plot(locs_Qwave,ssc3(locs_Qwave),'rv','MarkerFaceColor','r'),hold on, plot(ssc3),hold on,plot(pospicos,ssc3(pospicos),'k*')

%EMPIEZE Y ACABADO QRS
figure;plot(t3,ecg_i2,t3(Q_t),Q_A,'*b'),hold on,
plot(t3,ecg_i2,t3(S_t),(S_A),'*r'),hold on, plot(t3,ecg_i2)

figure,plot(ssc3),hold on,
plot(Q_t,ssc3(Q_t),'rs','MarkerFaceColor','g'),hold on,
plot(S_t,ssc3(S_t),'rv','MarkerFaceColor','r')

%PERFORMANCE
ann3=rdann('mitdb/103','atr',[],21600);
figure, plot(ann3,ssc3(ann3),'k*'), hold on, 
 plot(ssc3),hold on,plot(pospicos,ssc3(pospicos),'r*')
 FP4=[];
 VP4= [];
 FN4=[];
 detec4=[];
 for i=1:length(pospicos)
     if ann3(find(ann3 >= (pospicos(i)-15) & ann3 <= (pospicos(i)+15)))
     detec4= [detec4 pospicos(i)];
     VP4=[VP4 pospicos(i)];
     else
         FP4=[FP4 pospicos(i)]; 
     end
 end
detec4=[];
 for j=1:length(ann3)
      if pospicos(find(pospicos >= (ann3(j)-15) & pospicos <= (ann3(j)+15)))
    detec4= [detec4 ann3(j)];
      else
         FN4=[FN4 ann3(j)]; 
      end
 end
 VP4=length(VP4);
 FP4=length(FP4);
 FN4=length(FN4);
 sensibilidad4= VP4/(VP4+FN4);
 valorP4=VP4/(VP4+FP4);


 %SEÑAL 5
 %CARGAR SEÑAL
  [signal,Fs,tm]=rdsamp('mitdb/104',[],21600);
signal=signal(:,1);
%PRE-PROCESAMIENTO
t5=(0:length(signal)-1)/Fs;
%Ajustar amplitud
ecg_mv= (signal)/max(signal);%Amplitud ajustada
continua= mean(ecg_mv);
%Después le quitamos esa media a los valores de la señal original
ssc5=(ecg_mv-continua)/std(ecg_mv);
ssc5=ssc5/max(ssc5);
%En el dominio del tiempo
figure, subplot(211), plot(t5,signal), title('Señal original'), subplot(212),plot(t5,ssc5,'r'),title('Señal sin continua')
%Transformada de fourier sin continua
tfshiftssc=fftshift(fft(ssc5));
% Creamos el eje para hacer un eje de tiempos
ejeff= linspace(-Fs/2,Fs/2,length(tfshiftssc));
%Gráficamos utilizando el subplot
figure, subplot(121),plot(ejeff,abs(tfshiftssc/length(ssc5))),title('Señal sin continua')

%FUNCION
[pospicos,elecg,elecgO,ecg_d,ecg_e,ecg_C,ecg_i,ecg_i2,locs_Qwave,S_A, S_t,Q_A,Q_t]=qrs_deteccion_prueba(ssc5,t5,Fs);

%FILTRADO DE ARTEFACTOS
%PASO BAJO
%En el dominio del tiempo
figure, subplot(211), plot(t5,ssc5), title('Señal original'), subplot(212),plot(t5,elecg,'r'),title('Señal filtrada FPB')
%En el dominio de la frecuencia
tfshiftssc1=fftshift(fft(elecg));
% Creamos el eje para hacer un eje de tiempos
ejeff1= linspace(-Fs/2,Fs/2,length(tfshiftssc1));
%Gráficamos utilizando el subplot
figure, subplot(211),plot(ejeff1,abs(tfshiftssc1/length(elecg))),title('Transformada de Fourier de la Señal FPB'),subplot(212), plot(ejeff,abs(tfshiftssc/length(ssc5))),title('Transformada de Fourier de la Señal pre-procesada')

%PASO ALTO
figure, subplot(211), plot(t5,elecg), title('Señal filtrada FPB'), subplot(212),plot(t5,elecgO,'r'),title('Señal filtrada FPA')
%En el dominio de la frecuencia
tfshiftssc2=fftshift(fft(elecgO));
% Creamos el eje para hacer un eje de tiempos
ejeff2= linspace(-Fs/2,Fs/2,length(tfshiftssc2));
%Gráficamos utilizando el subplot
figure, subplot(211),plot(ejeff1,abs(tfshiftssc2/length(elecgO))),title('Transformada de Fourier de la Señal FPA'),subplot(212), plot(ejeff1,abs(tfshiftssc/length(elecg))),title('Transformada de Fourier de la Señal FPB')

%DERIVACION
figure,plot(t5,ecg_d)
%ELEVAR A 2
figure,plot(t5,ecg_e)
%INTEGRACION
 figure,plot(t5,ecg_i)
 %UMBRAL
   figure, plot(t5,ecg_C),hold on, plot(t5,ecg_i,'r')
 
   %DETECCION DE LATIDOS
figure,plot(locs_Qwave,ssc5(locs_Qwave),'rv','MarkerFaceColor','r'),hold on, plot(ssc5),hold on,plot(pospicos,ssc5(pospicos),'k*')

%EMPIEZE Y ACABADO QRS
figure;plot(t5,ecg_i2,t5(Q_t),Q_A,'*b'),hold on,
plot(t5,ecg_i2,t5(S_t),(S_A),'*r'),hold on, plot(t5,ecg_i2)

figure,plot(ssc5),hold on,
plot(Q_t,ssc5(Q_t),'rs','MarkerFaceColor','g'),hold on,
plot(S_t,ssc5(S_t),'rv','MarkerFaceColor','r')

%PERFORMANCE
ann5=rdann('mitdb/104','atr',[],21600);
figure, plot(ssc5),hold on,plot(ann5,ssc5(ann5),'k*'), hold on, 
 plot(pospicos,ssc5(pospicos),'r*')
  FP5=[];
 VP5= [];
 FN5=[];
 detec5=[];
 for i=1:length(pospicos)
     if ann5(find(ann5 >= (pospicos(i)-15) & ann5 <= (pospicos(i)+15)))
     detec5= [detec5 pospicos(i)];
     VP5=[VP5 pospicos(i)];

     else
         FP5=[FP5 pospicos(i)]; 
         
     end
 end
detec5=[];
 for j=1:length(ann5)
      if pospicos(find(pospicos >= (ann5(j)-15) & pospicos <= (ann5(j)+15)))
    detec5= [detec5 ann5(j)];
      else
         FN5=[FN5 ann5(j)]; 
      end
 end
 VP5=length(VP5);
 FP5=length(FP5);
 FN5=length(FN5);
 sensibilidad5= VP5/(VP5+FN5);
 valorP5=VP5/(VP5+FP5);



  %SEÑAL 6
  %CARGAR SEÑAL
  [signal,Fs,tm]=rdsamp('mitdb/105',[],21600);
signal=signal(:,1);

%PRE-PROCESAMIENTO
tt6=(0:length(signal)-1)/Fs;
%Ajustar amplitud
ecg_mv= (signal)/max(signal);%Amplitud ajustada
continua= mean(ecg_mv);
%Después le quitamos esa media a los valores de la señal original
ssc6O=(ecg_mv-continua)/std(ecg_mv);
ssc6O=ssc6O/max(ssc6O);

figure, subplot(211), plot(tt6,signal), title('Señal original'), subplot(212),plot(tt6,ssc6O,'r'),title('Señal sin continua')
%Transformada de fourier sin continua
tfshiftssc=fftshift(fft(ssc6O));
% Creamos el eje para hacer un eje de tiempos
ejeff= linspace(-Fs/2,Fs/2,length(tfshiftssc))
%Gráficamos utilizando el subplot
figure, subplot(121),plot(ejeff,abs(tfshiftssc/length(ssc6O))),title('Transformada de Fourier')

%FUNCION
[pospicos,elecg,elecgO,ecg_d,ecg_e,ecg_C,ecg_i,ecg_i2,locs_Qwave,S_A, S_t,Q_A,Q_t]=qrs_deteccion_prueba(ssc6O,tt6,Fs);

%FILTRADO DE ARTEFACTOS
%PASO BAJO
figure, subplot(211), plot(tt6,ssc6O), title('Señal original'), subplot(212),plot(tt6,elecg,'r'),title('Señal filtrada')
%En el dominio de la frecuencia
tfshiftssc1=fftshift(fft(elecg));
% Creamos el eje para hacer un eje de tiempos
ejeff1= linspace(-Fs/2,Fs/2,length(tfshiftssc1));
%Gráficamos utilizando el subplot
figure, subplot(211),plot(ejeff1,abs(tfshiftssc1/length(elecg))),title('Transformada de Fourier de la Señal FPB'),subplot(212), plot(ejeff,abs(tfshiftssc/length(ssc6O))),title('Transformada de Fourier de la Señal pre-procesada')

%PASO ALTO
figure, subplot(211), plot(tt6,elecg), title('Señal filtrada FPB'), subplot(212),plot(tt6,elecgO,'r'),title('Señal filtrada FPA')
%En el dominio de la frecuencia
tfshiftssc2=fftshift(fft(elecgO));
% Creamos el eje para hacer un eje de tiempos
ejeff2= linspace(-Fs/2,Fs/2,length(tfshiftssc2));
%Gráficamos utilizando el subplot
figure, subplot(211),plot(ejeff2,abs(tfshiftssc2/length(elecgO))),title('Transformada de Fourier de la Señal FPA'),subplot(212), plot(ejeff1,abs(tfshiftssc1/length(elecg))),title('Transformada de Fourier de FPB')


%DERIVACION
figure,plot(tt6,ecg_d)
%ELEVAR A 2
figure,plot(tt6,ecg_e)
%INTEGRACION
figure, plot(tt6,ecg_i)
 %UMBRAL
   figure, plot(tt6,ecg_C),hold on, plot(tt6,ecg_i,'r')
 
   %DETECCION DE LATIDOS
figure, plot(locs_Qwave,ssc6O(locs_Qwave),'rv','MarkerFaceColor','r'),hold on, plot(ssc6O),hold on,plot(pospicos,ssc6O(pospicos),'k*')

%EMPIEZE Y ACABADO QRS
figure;plot(tt6,ecg_i2,tt6(Q_t),Q_A,'*b'),hold on,
plot(tt6,ecg_i2,tt6(S_t),(S_A),'*r'),hold on, plot(tt6,ecg_i2)

figure,plot(ssc6O),hold on,
plot(Q_t,ssc6O(Q_t),'rs','MarkerFaceColor','g'),hold on,
plot(S_t,ssc6O(S_t),'rv','MarkerFaceColor','r')

%PERFORMANCE
ann6=rdann('mitdb/105','atr',[],21600);
 plot(ssc6O),hold on,plot(ann6,ssc6O(ann6),'k*'), hold on, 
 plot(pospicos,ssc6O(pospicos),'r*')
  FP6=[];
 VP6= [];
 FN6=[];
 detec6=[];
 for i=1:length(pospicos)
     if ann6(find(ann6 >= (pospicos(i)-15) & ann6 <= (pospicos(i)+15)))
     detec6= [detec6 pospicos(i)];
      VP6=[VP6 pospicos(i)];
     else
         FP=[FP pospicos(i)];
   
        
     end
     end

 
detec6=[];
 for j=1:length(ann6)
      if pospicos(find(pospicos >= (ann6(j)-15) & pospicos <= (ann6(j)+15)))
    detec6= [detec6 ann6(j)]
      else
         FN6=[FN6 ann6(j)]; 
      end
 end
 VP6=length(VP6);
 FP6=length(FP6);
 FN6=length(FN6);
 sensibilidad6= VP6/(VP6+FN6);
 valorP6=VP6/(VP6+FP6);



  %SEÑAL 7
  %CARGAR SEÑALES
  [signal,Fs,tm]=rdsamp('mitdb/106',[],21600);
signal=signal(:,1);

%PRE-PROCESAMIENTO 
t7=(0:length(signal)-1)/Fs;
%Ajustar amplitud
ecg_mv= (signal)/max(signal);%Amplitud ajustada
continua= mean(ecg_mv);
%Después le quitamos esa media a los valores de la señal original
ssc7=(ecg_mv-continua)/std(ecg_mv);
ssc7=ssc7/max(ssc7);

figure, subplot(211), plot(t7,signal), title('Señal original'), subplot(212),plot(t7,ssc7,'r'),title('Señal sin continua')
%Dominio en frecuencia
tfshiftssc=fftshift(fft(ssc7));
% Creamos el eje para hacer un eje de tiempos
ejeff= linspace(-Fs/2,Fs/2,length(tfshiftssc));
%Gráficamos utilizando el subplot
figure, subplot(121),plot(ejeff,abs(tfshiftssc/length(ssc7))),title('Transformada de Fourier Señal sin continua');
%FUNCION
[pospicos,elecg,elecgO,ecg_d,ecg_e,ecg_C,ecg_i,ecg_i2,locs_Qwave,S_A, S_t,Q_A,Q_t]=qrs_deteccion_prueba(ssc7,t7,Fs)
%FILTRADO DE ARTEFACTOS
%PASO BAJO
figure, subplot(211), plot(t7,ssc7), title('Señal original'), subplot(212),plot(t7,elecg,'r'),title('Señal filtrada FPB')
%En el dominio de la frecuencia
tfshiftssc1=fftshift(fft(elecg));
% Creamos el eje para hacer un eje de tiempos
ejeff1= linspace(-Fs/2,Fs/2,length(tfshiftssc1));
%Gráficamos utilizando el subplot
figure, subplot(211),plot(ejeff1,abs(tfshiftssc1/length(elecg))),title('Transformada de Fourier de la Señal FPB'),subplot(212), plot(ejeff,abs(tfshiftssc/length(ssc7))),title('Transformada de Fourier de la Señal pre-procesada')

%PASO ALTO
figure, subplot(211), plot(t7,elecg), title('Señal filtrada FPB'), subplot(212),plot(t7,elecgO,'r'),title('Señal filtrada FPA')
%En el dominio de la frecuencia
tfshiftssc2=fftshift(fft(elecgO));
% Creamos el eje para hacer un eje de tiempos
ejeff2= linspace(-Fs/2,Fs/2,length(tfshiftssc2));
%Gráficamos utilizando el subplot
figure, subplot(211),plot(ejeff2,abs(tfshiftssc2/length(elecgO))),title('Transformada de Fourier de la Señal FPA'),subplot(212), plot(ejeff1,abs(tfshiftssc1/length(elecg))),title('Transformada de Fourier de la Señal FPB')


%DERIVACION
figure,plot(t7,ecg_d)
%ELEVAR A 2
figure,plot(t7,ecg_e)
%INTEGRACION
 figure,plot(t7,ecg_i)
 %UMBRAL
   figure, plot(t7,ecg_C),hold on, plot(t7,ecg_i,'r')
  
   %DETECCION DE LATIDOS
figure,plot(locs_Qwave,ssc7(locs_Qwave),'rv','MarkerFaceColor','r'),hold on, plot(ssc7),hold on,plot(pospicos,ssc7(pospicos),'k*')
%EMPIEZE Y ACABADO QRS
figure;plot(t7,ecg_i2,t7(Q_t),Q_A,'*b'),hold on,
plot(t7,ecg_i2,t7(S_t),(S_A),'*r'),hold on, plot(t7,ecg_i2)

plot(ssc7),hold on,
plot(Q_t,ssc7(Q_t),'rs','MarkerFaceColor','g'),hold on,
plot(S_t,ssc7(S_t),'rv','MarkerFaceColor','r')

%PERFORMANCE
ann7=rdann('mitdb/106','atr',[],21600);
 plot(ssc7),hold on,plot(ann7,ssc7(ann7),'k*'), hold on, 
 plot(locs_Qwave,ssc7(locs_Qwave),'r*')
  FP7=[];
 VP7= [];
 FN7=[];
 detec7=[];
 for i=1:length(locs_Qwave)
     if ann7(find(ann7 >= (locs_Qwave(i)-15) & ann7 <= (locs_Qwave(i)+15)))
     detec7= [detec7 locs_Qwave(i)];
     VP7=[VP7 locs_Qwave(i)];
     else
         FP7=[FP7 locs_Qwave(i)];
     end
 end
detec7=[];
 for j=1:length(ann7)
      if locs_Qwave(find(locs_Qwave >= (ann7(j)-15) & locs_Qwave <= (ann7(j)+15)))
    detec7= [detec7 ann7(j)]; 
      else
         FN7=[FN7 ann7(j)]; 
      end
 end
 VP7=length(VP7);
 FP7=length(FP7);
 FN7=length(FN7);
 sensibilidad7= VP7/(VP7+FN7);
 valorP7=VP7/(VP7+FP7);


  %SEÑAL 8
  %CARGAR SEÑAL
  [signal,Fs,tm]=rdsamp('mitdb/107',[],21600);
signal=signal(:,1);
%PRE_PROCESAMIENTO
t8=(0:length(signal)-1)/Fs;
%Ajustar amplitud
ecg_mv= (signal)/max(signal);%Amplitud ajustada
figure,plot(t8,ecg_mv);
continua= mean(ecg_mv);
%Después le quitamos esa media a los valores de la señal original
ssc8=(ecg_mv-continua)/std(ecg_mv);
ssc8=ssc8/max(ssc8);

figure, subplot(211), plot(t8,signal), title('Señal original'), subplot(212),plot(t8,ssc8,'r'),title('Señal sin continua')
%Transformada de fourier sin continua
tfshiftssc=fftshift(fft(ssc8));
% Creamos el eje para hacer un eje de tiempos
ejeff= linspace(-Fs/2,Fs/2,length(tfshiftssc))
%Gráficamos utilizando el subplot
figure, subplot(121),plot(ejeff,abs(tfshiftssc/length(ssc8))),title(' Transformada de Fourier Señal sin continua')

%FUNCION
[pospicos,elecg,elecgO,ecg_d,ecg_e,ecg_C,ecg_i,ecg_i2,locs_Qwave,S_A, S_t,Q_A,Q_t]=qrs_deteccion_prueba(ssc8,t8,Fs);

%PASO BAJO
figure, subplot(211), plot(t8,ssc8), title('Señal original'), subplot(212),plot(t8,elecg,'r'),title('Señal filtrada FPB')
%En el dominio de la frecuencia
tfshiftssc1=fftshift(fft(elecg));
% Creamos el eje para hacer un eje de tiempos
ejeff1= linspace(-Fs/2,Fs/2,length(tfshiftssc1))
%Gráficamos utilizando el subplot
figure, subplot(211),plot(ejeff1,abs(tfshiftssc1/length(elecg))),title('Transformada de Fourier de la Señal FPB'),subplot(212), plot(ejeff,abs(tfshiftssc/length(ssc8))),title('Transformada de Fourier de la Señal pre-procesada')

%PASO ALTO
figure, subplot(211), plot(t8,elecg), title('Señal filtrada FPB'), subplot(212),plot(t8,elecgO,'r'),title('Señal filtrada FPA')

%En el dominio de la frecuencia
tfshiftssc2=fftshift(fft(elecgO));
% Creamos el eje para hacer un eje de tiempos
ejeff2= linspace(-Fs/2,Fs/2,length(tfshiftssc2));
%Gráficamos utilizando el subplot
figure, subplot(211),plot(ejeff2,abs(tfshiftssc2/length(elecgO))),title('Transformada de Fourier de la Señal FPA'),subplot(212), plot(ejeff1,abs(tfshiftssc1/length(elecg))),title('Transformada de Fourier de la Señal FPA')

%DERIVACION
figure,plot(t8,ecg_d)
%ELEVAR A 2
figure,plot(t8,ecg_e)
%INTEGRACION
figure, plot(t8,ecg_i)
 %UMBRAL
   figure, plot(t8,ecg_C),hold on, plot(t8,ecg_i,'r')
   %DETECCION DE LATIDOS
figure,plot(locs_Qwave,ssc8(locs_Qwave),'rv','MarkerFaceColor','r'),hold on, plot(ssc8),hold on,plot(pospicos,ssc8(pospicos),'k*')
%EMPIEZE Y ACABADO QRS
figure;plot(t8,ecg_i2,t8(Q_t),Q_A,'*b'),hold on,
plot(t8,ecg_i2,t8(S_t),(S_A),'*r'),hold on, plot(t8,ecg_i2)

figure,plot(ssc8),hold on,
plot(Q_t,ssc8(Q_t),'rs','MarkerFaceColor','g'),hold on,
plot(S_t,ssc8(S_t),'rv','MarkerFaceColor','r')

%PERFORMANCE
ann8=rdann('mitdb/107','atr',[],21600);
 plot(ssc8),hold on,plot(ann8,ssc8(ann8),'k*'), hold on, 
 plot(pospicos,ssc8(pospicos),'r*')
  FP8=[];
 VP8= [];
 FN8=[];
 detec8=[];
 for i=1:length(pospicos)
     if ann8(find(ann8 >= (pospicos(i)-15) & ann8 <= (pospicos(i)+15)))
     detec8= [detec8 pospicos(i)];
     VP8=[VP8 pospicos(i)];
     else
         FP8=[FP8 pospicos(i)];
 
     end
     end


detec8=[];
 for j=1:length(ann8)
      if pospicos(find(pospicos >= (ann8(j)-15) & pospicos <= (ann8(j)+15)))
    detec8= [detec8 ann8(j)];
      else
  
         FN8=[FN8 ann8(j)]; 
      end
 end
 VP8=length(VP8);
 FP8=length(FP8);
 FN8=length(FN8);
 sensibilidad8= VP8/(VP8+FN8);
 valorP8=VP8/(VP8+FP8);



 %SEÑAL 9
 %CARGAR SEÑAL
  [signal,Fs,tm]=rdsamp('mitdb/108',[],21600);
signal=signal(:,1);
%PRE_PROCESAMIENTO

t9=(0:length(signal)-1)/Fs;
%Ajustar amplitud
ecg_mv= (signal)/max(signal);%Amplitud ajustada
continua= mean(ecg_mv);
%Después le quitamos esa media a los valores de la señal original
ssc9=(ecg_mv-continua)/std(ecg_mv);
ssc9=ssc9/max(ssc9);

figure, subplot(211), plot(t9,signal), title('Señal original'), subplot(212),plot(t9,ssc9,'r'),title('Señal sin continua')
%Dominio de la frecuencia
tfshiftssc=fftshift(fft(ssc9));
% Creamos el eje para hacer un eje de tiempos
ejeff= linspace(-Fs/2,Fs/2,length(tfshiftssc))
%Gráficamos utilizando el subplot
figure, subplot(121),plot(ejeff,abs(tfshiftssc/length(ssc9))),title('Señal sin continua')
%FUNCION
[pospicos,elecg,elecgO,ecg_d,ecg_e,ecg_C,ecg_i,ecg_i2,locs_Qwave,S_A, S_t,Q_A,Q_t]=qrs_deteccion_prueba(ssc9,t9,Fs);
%PASO BAJO
figure, subplot(211), plot(t9,ssc9), title('Señal original'), subplot(212),plot(t9,elecg,'r'),title('Señal filtrada FPB')
%En el dominio de la frecuencia
tfshiftssc1=fftshift(fft(elecg));
% Creamos el eje para hacer un eje de tiempos
ejeff1= linspace(-Fs/2,Fs/2,length(tfshiftssc1));
%Gráficamos utilizando el subplot
figure, subplot(211),plot(ejeff1,abs(tfshiftssc1/length(elecg))),title('Transformada de Fourier de la Señal FPB'),subplot(212), plot(ejeff,abs(tfshiftssc/length(ssc9))),title('Transformada de Fourier de la Señal pre-procesada')

%PASO ALTO
figure, subplot(211), plot(t9,elecg), title('Señal filtrada FPB'), subplot(212),plot(t9,elecgO,'r'),title('Señal filtrada FPA')
%En el dominio de la frecuencia
tfshiftssc2=fftshift(fft(elecgO));
% Creamos el eje para hacer un eje de tiempos
ejeff2= linspace(-Fs/2,Fs/2,length(tfshiftssc2));
%Gráficamos utilizando el subplot
figure, subplot(211),plot(ejeff2,abs(tfshiftssc2/length(elecgO))),title('Transformada de Fourier de la Señal FPA'),subplot(212), plot(ejeff1,abs(tfshiftssc1/length(elecg))),title('Transformada de Fourier de la Señal FPB')

%DERIVACION
figure,plot(t9,ecg_d)
%ELEVAR A 2
figure,plot(t9,ecg_e)
%INTEGRACION
 figure,plot(t9,ecg_i)
 %UMBRAL
   figure, plot(t9,ecg_C),hold on, plot(t9,ecg_i,'r')
   
   %DETECCION DE LATIDOS
figure,plot(locs_Qwave,ssc9(locs_Qwave),'rv','MarkerFaceColor','r'),hold on, plot(ssc9),hold on,plot(pospicos,ssc9(pospicos),'k*')
%EMPIEZE Y ACABADO QRS
figure;plot(t9,ecg_i2,t9(Q_t),Q_A,'*b'),hold on,
plot(t9,ecg_i2,t9(S_t),(S_A),'*r'),hold on, plot(t9,ecg_i2)

figure,plot(ssc9),hold on,
plot(Q_t,ssc9(Q_t),'rs','MarkerFaceColor','g'),hold on,
plot(S_t,ssc9(S_t),'rv','MarkerFaceColor','r')
%PERFORMANCE
ann9=rdann('mitdb/108','atr',[],21600);
 figure,plot(ssc9),hold on,plot(ann9,ssc9(ann9),'k*'), hold on, 
 plot(locs_Qwave,ssc9(locs_Qwave),'r*')
  FP9=[];
 VP9= [];
 FN9=[];
 detec9=[];
 for i=1:length(locs_Qwave)
     if ann9(find(ann9 >= (locs_Qwave(i)-15) & ann9 <= (locs_Qwave(i)+15)))
     detec9= [detec9 locs_Qwave(i)];
     VP9=[VP9 locs_Qwave(i)];
     else 
       FP9=[FP9 locs_Qwave(i)] 
     end
 end
detec9=[];
 for j=1:length(ann9)
      if locs_Qwave(find(locs_Qwave >= (ann9(j)-15) & locs_Qwave <= (ann9(j)+15)))
    detec9= [detec9 ann9(j)];
      else
         FN9=[FN9 ann9(j)]; 
      end
 end
 VP9=length(VP9);
 FP9=length(FP9);
 FN9=length(FN9);
 sensibilidad9= VP9/(VP9+FN9);
 valorP9=VP9/(VP9+FP9);


  %SEÑAL 10
  %CARGAR SEÑAL
  [signal,Fs,tm]=rdsamp('mitdb/123',[],21600);
signal=signal(:,1);
%PRE-PROCESAMIENTO
t10=(0:length(signal)-1)/Fs;
%Ajustar amplitud
ecg_mv= (signal)/max(signal);%Amplitud ajustada
continua= mean(ecg_mv);%Centrar en el eje 0
%Después le quitamos esa media a los valores de la señal original
ssc10=(ecg_mv-continua)/std(ecg_mv);
ssc10=ssc10/max(ssc10);

figure, subplot(211), plot(t10,signal), title('Señal original'), subplot(212),plot(t10,ssc10,'r'),title('Señal sin continua')
%Transformada de fourier sin continua
tfshiftssc=fftshift(fft(ssc10));
% Creamos el eje para hacer un eje de tiempos
ejeff= linspace(-Fs/2,Fs/2,length(tfshiftssc));
%Gráficamos utilizando el subplot
figure, subplot(121),plot(ejeff,abs(tfshiftssc/length(ssc10))),title('Señal sin continua')
%FUNCION
[pospicos,elecg,elecgO,ecg_d,ecg_e,ecg_C,ecg_i,ecg_i2,locs_Qwave,S_A, S_t,Q_A,Q_t]=qrs_deteccion_prueba(ssc10,t10,Fs);
%FILTRAR ARTEFACTOS
%PASO BAJO
figure, subplot(211), plot(t10,ssc10), title('Señal original'), subplot(212),plot(t10,elecg,'r'),title('Señal filtrada FPB')
%En el dominio de la frecuencia
tfshiftssc1=fftshift(fft(elecg));
% Creamos el eje para hacer un eje de tiempos
ejeff1= linspace(-Fs/2,Fs/2,length(tfshiftssc1));
%Gráficamos utilizando el subplot
figure, subplot(211),plot(ejeff1,abs(tfshiftssc1/length(elecg))),title('Transformada de Fourier de la Señal FPB'),subplot(212), plot(ejeff,abs(tfshiftssc/length(ssc10))),title('Transformada de Fourier de la Señal pre-procesada')

%PASO ALTO
figure, subplot(211), plot(t10,elecg), title('Señal original'), subplot(212),plot(t10,elecgO,'r'),title('Señal filtrada')
%En el dominio de la frecuencia
tfshiftssc2=fftshift(fft(elecgO));
% Creamos el eje para hacer un eje de tiempos
ejeff2= linspace(-Fs/2,Fs/2,length(tfshiftssc2));
%Gráficamos utilizando el subplot
figure, subplot(211),plot(ejeff2,abs(tfshiftssc2/length(elecgO))),title('Transformada de Fourier de la Señal FPA'),subplot(212), plot(ejeff1,abs(tfshiftssc1/length(elecg))),title('Transformada de Fourier de la Señal FPB')
%DERIVACION
figure,plot(t10,ecg_d)
%ELEVAR A 2
figure,plot(t10,ecg_e)
%INTEGRACION
 figure,plot(t10,ecg_i)
 %UMBRAL
   figure, plot(t10,ecg_C),hold on, plot(t10,ecg_i,'r'),hold on, plot(t10,ssc10)
 
   %DETECCION DE LATIDOS
figure,plot(locs_Qwave,ssc10(locs_Qwave),'rv','MarkerFaceColor','r'),hold on, plot(ssc10),hold on,plot(pospicos,ssc10(pospicos),'k*')
%EMPIEZE Y ACABADO QRS
figure;plot(t10,ecg_i2,t10(Q_t),Q_A,'*b'),hold on,
plot(t10,ecg_i2,t10(S_t),(S_A),'*r'),hold on, plot(t10,ecg_i2)

figure,plot(ssc10),hold on,
plot(Q_t,ssc10(Q_t),'rs','MarkerFaceColor','g'),hold on,
plot(S_t,ssc10(S_t),'rv','MarkerFaceColor','r')
%EJERCICIO 6
ann10=rdann('mitdb/123','atr',[],21600);
 plot(ssc10),hold on,plot(ann10,ssc10(ann10),'k*'), hold on, 
 plot(pospicos,ssc10(pospicos),'r*')
  FP10=[];
 VP10= [];
 FN10=[];
 detec10=[];
 for i=1:length(locs_Qwave)
     if ann10(find(ann10 >= (locs_Qwave(i)-15) & ann10 <= (locs_Qwave(i)+15)))
     detec10= [detec10 locs_Qwave(i)];
     VP10=[VP10 locs_Qwave(i)];
     else 
       FP10=[FP10 locs_Qwave(i)] ;
     end
     

 end
detec10=[];
 for j=1:length(ann10)
      if locs_Qwave(find(locs_Qwave >= (ann10(j)-15) & locs_Qwave <= (ann10(j)+15)))
    detec10= [detec10 ann10(j)];
      else
         FN10=[FN10 ann10(j)]; 
      end
 end
 VP10=length(VP10);
 FP10=length(FP10);
 FN10=length(FN10);
 sensibilidad10= VP10/(VP10+FN10);
 valorP10=VP10/(VP10+FP10);

 %EVALUACION DEL RENDIMIENTO DEL ALGORITMO
 %SENSIBILIDAD TOTAL
 sensT=(sensibilidad1 + sensibilidad2+ sensibilidad3 + sensibilidad4 + sensibilidad5 + sensibilidad6 + sensibilidad7 + sensibilidad8 + sensibilidad9 + sensibilidad10)/10;
 %VALOR PREDICTIVO POSITIVO
 valorPT=(valorP1 + valorP2 + valorP3 + valorP4 + valorP5 + valorP6 + valorP7 + valorP8 + valorP9 + valorP10)/10;